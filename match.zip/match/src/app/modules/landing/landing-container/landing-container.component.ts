import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-container',
  templateUrl: './landing-container.component.html',
  styleUrls: ['./landing-container.component.css']
})
export class LandingContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
