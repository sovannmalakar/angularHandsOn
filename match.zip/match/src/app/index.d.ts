
declare module 'googlemaps';