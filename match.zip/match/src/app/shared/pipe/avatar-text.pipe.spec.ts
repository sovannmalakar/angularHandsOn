import { AvatarTextPipe } from './avatar-text.pipe';

describe('AvatarTextPipe', () => {
  it('create an instance', () => {
    const pipe = new AvatarTextPipe();
    expect(pipe).toBeTruthy();
  });
});
