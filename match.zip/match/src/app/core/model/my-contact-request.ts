﻿

export class MyContactRequest {
    fullName: '';
    approvalRequestGuid: string;
    firstName:	string;
    lastName:	string;
    companyName: string;
    notes:	string;
    waitingForConfirmationFromOthers: boolean;
    length: number;
}
