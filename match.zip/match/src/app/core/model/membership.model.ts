
export class MembershipModel {
    membershipGuid: string;
    membershipName: string;
  }
