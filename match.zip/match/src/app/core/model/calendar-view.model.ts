﻿export class CalendarViewModel {
    calendarGuid: string;
    partnerGuid: string;
    partnerFirstName: string;
    partnerLastName: string;
    partnerCompanyName: string;
    calendarEntryType: number;
    startDate: string;
    endDate: string;
    title: string;
    notes: string;
}
