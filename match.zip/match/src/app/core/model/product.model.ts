﻿

export class ProductModel {
    productGuid: string;
    productName: string;
}
