export class CertificationModel {
    certificationGuid: string;
    certificationName: string;
  }
