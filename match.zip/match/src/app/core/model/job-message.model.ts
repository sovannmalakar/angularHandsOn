﻿export class JobMessageModel {
    productJobMessageGuid: string;
    fromPartnerGuid: string;
    fromPartnerFirstName: string;
    fromPartnerLastName: string;
    fromPartnerCompanyName: string;
    message: string;
}
