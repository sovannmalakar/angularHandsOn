
export class CalendarEntryModel {
    calendarGuid?:	string;
    calendarEntryType:	number;
    startDate:	Date;
    endDate: 	Date;
    title:	string;
    notes:	string;
}
