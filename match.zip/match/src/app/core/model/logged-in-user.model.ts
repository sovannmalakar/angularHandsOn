﻿

export class LoggedInUserModel {
    userName: string;
    firstName: string;
    lastName: string;
    userType: number;
    token: string;
    userCity: string;
    userLatitude: number;
    partnerGuid: string;
    userLongitude: number;
}
