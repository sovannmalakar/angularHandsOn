﻿export class ErrorItem {
    key: string;
    value: string;
}
