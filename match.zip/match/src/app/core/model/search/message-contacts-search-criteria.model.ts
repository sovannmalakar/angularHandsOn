
import { BaseSearchCriteria } from './base-search-criteria.model';

export class MessageContactSearchCriteria extends BaseSearchCriteria {
}
