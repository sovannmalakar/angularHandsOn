import { BaseSearchCriteria } from './base-search-criteria.model';


export  class MessageForOneContactSearchCriteria extends BaseSearchCriteria {
    contactGuid?: string;
}
