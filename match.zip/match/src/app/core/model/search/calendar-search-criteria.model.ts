import { BaseSearchCriteria } from './base-search-criteria.model';

export class CalendarSearchCriteria  {
    day?: string;
    month?: string;
    year?: number;
}
