export class JobPostStatsByCitynameAndJobCountModel {
    cityName:	string;
    jobCount:	string;
}
