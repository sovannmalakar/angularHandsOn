
export class ZipCodeModel {
    cityName: string;
    countryCode: string;
    zip: string;
    latitude: number;
    longitude: number;
}
