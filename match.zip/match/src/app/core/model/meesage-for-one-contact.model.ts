import { MessageModel } from './message.model';

export class MessageForOneContactModel extends MessageModel {

}
