﻿export class IReturnModel {
    httpCode: number;
    isSuccess: boolean;
}
