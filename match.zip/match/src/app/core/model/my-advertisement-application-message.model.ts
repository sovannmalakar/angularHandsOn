﻿
export class MyAdvertisementApplicationMessageModel {
    advertisementApplicationMessageGuid: string;
    message: string;
}
