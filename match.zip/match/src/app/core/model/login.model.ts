﻿

export class LoginModel {
    username: string;
    password: string;
    rememberMe: boolean;
}
