export class MessageRequestModel {
    toPartnerGuid: string;
    message: string;
}
