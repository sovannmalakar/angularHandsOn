﻿

export class MessageModel {
    messageGuid: string;
    messageTime: string;
    toPartnerGuid: string;
    fromPartnerGuid: string;
    message: string;
    you?: false;
}
